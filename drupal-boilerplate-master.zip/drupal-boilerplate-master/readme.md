# Drupal boilerplate code

This repo is used for storing example codes and defaults for common tasks when developing drupal projects. Code free to use :thumbsup:.

## Config translation example

This module provides an example of how to create a configuration form in a custom module and make it out-of-the-box translatable. 
